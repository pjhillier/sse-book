"""Targeted regression and coverage checks added by the Revision 10 review.

All authority and time values are test-oracle inputs. No real security mechanism,
storage durability, network, concurrent execution or physical system is tested.
"""
from dataclasses import replace
import math
import unittest
from activation_model import ActivationModel, Authority, Request, Rejected


class ReviewRegressionTests(unittest.TestCase):
    def setUp(self):
        self.m = ActivationModel()
        self.m.transition("RECOVERY")
        self.r = Request("TX-41", "operator", "D1", "P8", 27, 1, "RECOVERY")
        self.a = Authority("operator", "D1", "RECOVERY", True, True, 0, 1200,
                           approver="approver", approved_package="P8",
                           active_local_roles=True, epoch=1,
                           recovery_transaction="TX-41", recovery_generation=27,
                           issued_at=0, approver_authenticated=True)

    def go(self, request=None, authority=None, **kw):
        params = dict(now=18.0, delay_bound=.7, time_allowance=2.0)
        params.update(kw)
        return self.m.activate(request or self.r, authority or self.a, **params)

    def test_one_grant_cannot_authorize_a_second_transaction(self):
        self.go()
        second = replace(self.r, transaction="TX-42", expected_generation=28)
        with self.assertRaisesRegex(Rejected, "single-operation"):
            self.go(second)
        self.assertEqual(self.m.effect_count, 1)

    def test_unconsumed_grant_cannot_be_rebound_to_another_transaction(self):
        with self.assertRaisesRegex(Rejected, "single-operation"):
            self.go(replace(self.r, transaction="TX-42"))
        self.assertEqual(self.m.effect_count, 0)

    def test_grant_expected_generation_binding_is_checked(self):
        with self.assertRaisesRegex(Rejected, "single-operation"):
            self.go(authority=replace(self.a, recovery_generation=26))

    def test_missing_transaction_binding_rejected(self):
        with self.assertRaisesRegex(Rejected, "single-operation"):
            self.go(authority=replace(self.a, recovery_transaction=None))

    def test_missing_generation_binding_rejected(self):
        with self.assertRaisesRegex(Rejected, "single-operation"):
            self.go(authority=replace(self.a, recovery_generation=None))

    def test_missing_approver_authentication_rejected(self):
        with self.assertRaisesRegex(Rejected, "independent recovery"):
            self.go(authority=replace(self.a, approver_authenticated=False))

    def test_missing_issuance_time_rejected(self):
        with self.assertRaisesRegex(Rejected, "issuance or lifetime"):
            self.go(authority=replace(self.a, issued_at=None))

    def test_future_issuance_rejected(self):
        with self.assertRaisesRegex(Rejected, "issuance or lifetime"):
            self.go(authority=replace(self.a, issued_at=19))

    def test_nonfinite_issuance_rejected(self):
        with self.assertRaisesRegex(Rejected, "issuance or lifetime"):
            self.go(authority=replace(self.a, issued_at=math.nan))

    def test_grant_lifetime_over_twenty_minutes_rejected(self):
        with self.assertRaisesRegex(Rejected, "issuance or lifetime"):
            self.go(authority=replace(self.a, expires_at=1200.1))

    def test_exactly_twenty_minute_grant_can_be_used_before_expiry(self):
        self.go()
        self.assertEqual(self.m.effect_count, 1)

    def test_commit_at_expiry_is_rejected(self):
        with self.assertRaisesRegex(Rejected, "expired or future"):
            self.go(authority=replace(self.a, expires_at=20.7))

    def test_commit_strictly_before_expiry_is_allowed(self):
        self.go(authority=replace(self.a, expires_at=20.701))
        self.assertEqual(self.m.effect_count, 1)

    def test_lost_reply_retry_preserves_single_recovery_effect(self):
        with self.assertRaises(TimeoutError):
            self.go(lose_reply_after_commit=True)
        outcome = self.go()
        self.assertEqual(outcome.committed_generation, 28)
        self.assertEqual(self.m.effect_count, 1)

    def test_new_operation_needs_new_bound_grant(self):
        self.go()
        second = replace(self.r, transaction="TX-42", package="P9", expected_generation=28)
        grant = replace(self.a, recovery_transaction="TX-42", recovery_generation=28,
                        approved_package="P9", issued_at=19, expires_at=1219)
        self.go(second, grant, now=20)
        self.assertEqual(self.m.effect_count, 2)
        self.assertEqual(self.m.generation, 29)

    def test_withdrawal_before_commit_rejects_bound_grant(self):
        with self.assertRaisesRegex(Rejected, "independent recovery"):
            self.go(authority=replace(self.a, active_local_roles=False))
        self.assertEqual(self.m.effect_count, 0)

    def test_stale_mode_grant_cannot_create_effect(self):
        self.m.transition("NORMAL")
        self.m.transition("RECOVERY")
        with self.assertRaisesRegex(Rejected, "mode or epoch"):
            self.go()
        self.assertEqual(self.m.effect_count, 0)

    def test_same_mode_call_does_not_advance_epoch(self):
        self.m.transition("RECOVERY")
        self.assertEqual(self.m.epoch, 1)

    def test_unknown_mode_is_rejected_without_state_change(self):
        before = self.m.snapshot()
        with self.assertRaisesRegex(Rejected, "unknown mode"):
            self.m.transition("UNDEFINED")
        self.assertEqual(before, self.m.snapshot())

    def test_expired_retry_does_not_erase_historical_outcome(self):
        self.go()
        with self.assertRaisesRegex(Rejected, "expired or future"):
            self.go(now=1200)
        q = self.m.query("TX-41", authorized_reader=True)
        self.assertEqual(q["historical_outcome"]["committed_generation"], 28)
        self.assertEqual(self.m.effect_count, 1)

    def test_conflicting_reuse_is_not_masked_by_package_authority(self):
        self.go()
        with self.assertRaisesRegex(Rejected, "conflicting reuse"):
            self.go(replace(self.r, package="P9"), replace(self.a, approved_package="P9"))
        self.assertEqual(self.m.effect_count, 1)

    def test_precommit_interruption_does_not_consume_logical_operation(self):
        with self.assertRaisesRegex(Rejected, "injected interruption"):
            self.go(fail_before_commit=True)
        self.assertEqual(self.m.effect_count, 0)
        self.go()
        self.assertEqual(self.m.effect_count, 1)

    def test_current_snapshot_round_trip_preserves_recovery_history(self):
        self.go()
        snapshot = self.m.snapshot()
        self.m.restore(snapshot)
        self.go()
        self.assertEqual(snapshot, self.m.snapshot())

    def test_old_snapshot_after_mode_change_is_rejected(self):
        snapshot = self.m.snapshot()
        self.m.transition("NORMAL")
        with self.assertRaisesRegex(Rejected, "retained current anchor"):
            self.m.restore(snapshot)

    def test_role_loss_does_not_erase_an_already_committed_effect(self):
        self.go()
        with self.assertRaisesRegex(Rejected, "independent recovery"):
            self.go(authority=replace(self.a, active_local_roles=False))
        self.assertEqual(self.m.effect_count, 1)
        self.assertEqual(self.m.query("TX-41", authorized_reader=True)["current_generation"], 28)


if __name__ == "__main__":
    unittest.main()
