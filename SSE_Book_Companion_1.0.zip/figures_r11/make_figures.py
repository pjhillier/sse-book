from pathlib import Path
import subprocess, textwrap
import matplotlib.pyplot as plt
import numpy as np
OUT=Path('/mnt/data/r11_assets/figures')
BASE='''graph [bgcolor="white", pad="0.12", nodesep="0.28", ranksep="0.38", splines=polyline, fontname="DejaVu Sans", fontsize=11];\nnode [shape=box, style="rounded,filled", fillcolor="#f5f5f5", color="#222222", penwidth=1, fontname="DejaVu Sans", fontsize=11, margin="0.12,0.09"];\nedge [color="#333333", penwidth=1.1, arrowsize=0.65, fontname="DejaVu Sans", fontsize=9];'''
def render(name, body, rankdir='LR'):
    dot=f'digraph G {{\n{BASE}\ngraph [rankdir={rankdir}];\n{body}\n}}\n'
    (OUT/f'{name}.dot').write_text(dot)
    for fmt in ('svg','png'):
        subprocess.run(['dot',f'-T{fmt}',str(OUT/f'{name}.dot'),'-o',str(OUT/f'{name}.{fmt}')],check=True)

render('figure_2_1_context', r'''
subgraph cluster_soi { label="Administration capability (system of interest)"; color="#777777"; style="rounded,dashed";
  admin [label="Administrator / maintainer"];
  gw [label="Administration gateway\nSession + interaction"];
  coord [label="Receiving coordinator\nAuthority at commit"];
  store [label="Transaction + outcome state"];
  rec [label="Recovery path\nRestricted restoration"];
  admin -> gw -> coord;
  coord -> store [dir=both];
  rec -> coord;
}
idp [label="Enterprise identity / authority service\nExternal dependency",fillcolor="white"];
dispatch [label="Operational dispatch consumers\nOutside selected boundary",fillcolor="white"];
package [label="Package approval / supply\nExternal contribution",fillcolor="white"];
tools [label="Build • deployment • support tooling\nEnabling systems",fillcolor="white"];
idp -> gw [label="authentication / status"];
idp -> coord [label="authority status"];
package -> coord [label="eligible package"];
coord -> dispatch [label="active configuration"];
tools -> gw [style=dashed,label="change / support"];
tools -> coord [style=dashed];
''','TB')

render('figure_6_1_causal', r'''
loss [label="Loss L-01\nUnauthorized effective change",fillcolor="white"];
commit [label="Consequential event\nConfiguration commit"];
loss <- commit;
sa [label="Path A\nStale authority\nRevocation not reflected"];
sb [label="Path B\nAlternative writer\nBypasses main checks"];
sc [label="Path C\nRecovery authority\nToo broad / stale"];
sd [label="Path D\nEnabling-system change\nAlters enforcement or evidence"];
sa -> commit; sb -> commit; sc -> commit; sd -> commit;
a1 [label="Need\ncurrent authority at commit",fillcolor="white"];
a2 [label="Need\ncomplete writer coverage",fillcolor="white"];
a3 [label="Need\nbounded recovery action",fillcolor="white"];
a4 [label="Need\nprovenance + independent challenge",fillcolor="white"];
sa -> a1 [style=dashed,label="drives"];
sb -> a2 [style=dashed,label="drives"];
sc -> a3 [style=dashed,label="drives"];
sd -> a4 [style=dashed,label="drives"];
eval [label="Evaluation set\nTiming • path review • role tests • toolchain evidence"];
a1 -> eval; a2 -> eval; a3 -> eval; a4 -> eval;
''','LR')

render('figure_9_1_alternatives', r'''
subgraph cluster_a { label="ARC-A — Central dependency"; color="#999999"; style="rounded";
a1 [label="Admin"]; a2 [label="Enterprise identity"]; a3 [label="Gateway / receiver"]; a4 [label="Commit"]; a1 -> a2; a2 -> a3; a3 -> a4;
a5 [label="Identity outage",fillcolor="white"]; a5 -> a2 [style=dashed];
}
subgraph cluster_b { label="ARC-B — Governed recovery controller"; color="#777777"; style="rounded";
b1 [label="Normal admin"]; b2 [label="Enterprise identity"]; b3 [label="Receiver"]; b1 -> b2; b2 -> b3;
b4 [label="Recovery staff\nindependent MFA + approval"]; b5 [label="Recovery controller\nrestricted package selection"]; b4 -> b5; b5 -> b3;
b6 [label="Commit"]; b3 -> b6;
}
subgraph cluster_c { label="ARC-C — Prepared restoration capsule"; color="#555555"; style="rounded";
c1 [label="Normal services"]; c2 [label="Prepare target/package\nrestoration capsule"]; c1 -> c2;
c3 [label="Designated staff\nindependent authentication"]; c4 [label="Validate capsule\nstate + eligibility"]; c3 -> c4;
c5 [label="Receiver / commit"]; c2 -> c4; c4 -> c5;
}
''','TB')

render('figure_10_1_sequence', r'''
admin [label="Administrator"];
gw [label="Gateway"];
auth [label="Authority source"];
coord [label="Receiving coordinator"];
state [label="Protected state / history"];
admin -> gw [label="1 request TX-41"];
gw -> auth [label="2 obtain / validate authority"];
auth -> gw [label="3 status observation"];
gw -> coord [label="4 complete offer"];
coord -> auth [label="5 final authority check"];
auth -> coord [label="6 current status"];
coord -> state [label="7 atomic logical commit\nP7→P8; gen 27→28"];
state -> coord [label="8 outcome recorded"];
coord -> gw [label="9 reply (may be lost)"];
gw -> admin [label="10 outcome"];
retry [label="Matching retry after lost reply",fillcolor="white"];
retry -> coord [style=dashed,label="same TX-41"];
coord -> state [style=dashed,label="lookup history — no second effect"];
''','TB')

render('figure_12_1_modes', r'''
normal [label="NORMAL\nOrdinary administration"];
restricted [label="RESTRICTED\nDiagnosis / outcome only"];
quiesce [label="QUIESCING\nResolve or fence pending work"];
recovery [label="RECOVERY\nOnly approved restricted action"];
reconcile [label="RECONCILING\nState + history + authority"];
normal -> restricted [label="normal authority unavailable / stale"];
restricted -> quiesce [label="recovery need declared"];
quiesce -> recovery [label="profile + people + package + epoch valid"];
recovery -> reconcile [label="restoration committed / service returns"];
reconcile -> normal [label="normal basis re-established"];
reconcile -> restricted [label="basis incomplete"];
normal -> quiesce [style=dashed,label="controlled transition"];
''','LR')

render('figure_c_1_timing', r'''
t0 [shape=plaintext,label="t0\nrevocation recorded"];
t10 [shape=plaintext,label="t0 + 10 s\nlatest newly issued status\nthat may still omit revocation"];
t40 [shape=plaintext,label="t0 + 40 s\nlatest commit supported by\n30 s true-age bound"];
t60 [shape=plaintext,label="t0 + 60 s\nSR-03 deadline"];
t0 -> t10 [label="AUTH-C9 source consistency ≤10 s",minlen=2];
t10 -> t40 [label="SR-05 true-age-at-commit ≤30 s",minlen=3];
t40 -> t60 [label="20 s analytical room",minlen=2];
''','LR')

render('figure_19_2_assurance', r'''
claim [label="C-02\nCovered normal-mode authority",fillcolor="white"];
s1 [label="Subclaim\nEvery relevant writer is governed"];
s2 [label="Subclaim\nAuthority is current at commit"];
s3 [label="Subclaim\nTiming observations are applicable"];
e1 [label="Evidence\nPath / privilege review"];
e2 [label="Evidence\nSource-to-commit timing"];
e3 [label="Contrary evidence\nE-05-03 late commit",fillcolor="white"];
a1 [label="Assumption\nSource status semantics are correct",fillcolor="white"];
claim -> s1 [dir=back]; claim -> s2 [dir=back]; claim -> s3 [dir=back];
e1 -> s1; e2 -> s2; a1 -> s2 [style=dashed,label="depends"];
e3 -> s2 [color="#333333",penwidth=2,label="defeats unqualified claim"];
concl [label="Bounded conclusion\nSelected support useful;\nunqualified C-02 not supported"];
s1 -> concl; s2 -> concl; s3 -> concl;
''','LR')

render('figure_e_1_information_flow', r'''
source [label="Operational system\nDiagnostics + configuration"];
collector [label="Support collector\nSelect permitted fields"];
filter [label="Policy / minimization enforcement\nRemove secrets + unnecessary context"];
export [label="Protected export\nIdentity • integrity • confidentiality"];
supplier [label="Supplier support environment\nPermitted purpose + retention"];
archive [label="Customer evidence archive\nControlled retained copy"];
source -> collector -> filter -> export -> supplier;
filter -> archive [label="reviewable record"];
secrets [label="Credentials / unrelated operational data",fillcolor="white"]; secrets -> filter [style=dashed,label="must not pass unless specifically required"];
''','LR')

render('figure_f_1_compromise', r'''
normal [label="NORMAL\nSource trusted"];
suspect [label="SUSPECT SOURCE\nTimely information may be false"];
contain [label="CONTAIN\nStop source-dependent consequential actions"];
independent [label="INDEPENDENT BASIS\nKnown-good configuration / local evidence / separate authority"];
reconstitute [label="RECONSTITUTE\nRestore source, credentials, configuration and evidence"];
resume [label="CONTROLLED RETURN\nRe-establish normal reliance"];
normal -> suspect [label="credible compromise indication"];
suspect -> contain [label="claim depends on suspect source"];
contain -> independent [label="retain only functions with adequate independent basis"];
independent -> reconstitute [label="repair / rebuild / validate"];
reconstitute -> resume [label="evidence supports restored basis"];
resume -> normal [label="approved transition"];
''','LR')

# Charts
# Figure 11.2 trade sensitivity
w=np.linspace(0,1,201)
VB=0.20+0.55*w
VC=0.60-0.35*w
fig,ax=plt.subplots(figsize=(8.2,4.7))
ax.plot(w,VB,label='ARC-B value')
ax.plot(w,VC,label='ARC-C value')
ax.axvline(4/9,linestyle='--',linewidth=1)
ax.set_xlabel('Weight on defined cost-value swing, w')
ax.set_ylabel('Illustrative combined value')
ax.set_xlim(0,1); ax.set_ylim(0,0.85)
ax.grid(True,linewidth=0.4,alpha=0.5)
ax.legend(frameon=False)
ax.annotate('Preference crossover\nw = 4/9 ≈ 0.444',xy=(4/9,0.444),xytext=(0.57,0.67),arrowprops={'arrowstyle':'->'})
fig.tight_layout(); fig.savefig(OUT/'figure_11_2_trade_sensitivity.png',dpi=220); fig.savefig(OUT/'figure_11_2_trade_sensitivity.svg'); plt.close(fig)

# Figure D.2 stopping distance vs speed under baseline assumptions
speeds=np.linspace(0.4,2.0,161)
tau=.35; amin=.8; e=.15; m=.10
d=speeds*tau+speeds**2/(2*amin)+e+m
fig,ax=plt.subplots(figsize=(8.2,4.7))
ax.plot(speeds,d,label='Required distance')
ax.axhline(2.0,linestyle='--',linewidth=1,label='Assumed usable distance = 2.00 m')
for x in [1.2,1.8]:
    y=x*tau+x*x/(2*amin)+e+m
    ax.plot([x],[y],'o'); ax.annotate(f'{x:.1f} m/s → {y:.3f} m',xy=(x,y),xytext=(x-0.35,y+0.35 if x<1.5 else y-0.55),arrowprops={'arrowstyle':'->'})
ax.set_xlabel('Bounded forward speed v (m/s)')
ax.set_ylabel('Required stopping distance (m)')
ax.set_xlim(.4,2.0); ax.set_ylim(0,3.8)
ax.grid(True,linewidth=0.4,alpha=0.5); ax.legend(frameon=False,loc='upper left')
fig.tight_layout(); fig.savefig(OUT/'figure_D_2_stopping_curve.png',dpi=220); fig.savefig(OUT/'figure_D_2_stopping_curve.svg'); plt.close(fig)
