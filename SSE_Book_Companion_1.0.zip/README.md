# The Security-Engineering Convergence — technical companion (release staging)

Author: Peter J. Hillier. Intended book and teaching-material licence: CC BY 4.0, subject to final author approval and third-party rights clearance. **Not yet approved for public release.**

This package provides the current Python *teaching abstraction*, repeatable tests, illustrative engineering figures and five blank worksheet templates. It does not certify or test a real system or native MBSE export chain.

## Included materials
- `activation_model.py`: logical teaching model for one bounded remote-administration case
- `test_activation_model.py`, `test_review_regressions.py`: 60 unit/regression tests
- `arithmetic_checks.py`: 32 arithmetic/model calculation checks; `arithmetic_results.json` is a recorded result, not operational evidence
- `figures/` and `figures_r11/`: PNG/SVG figures and editable graph sources where available
- `worksheets/`: five editable CSV worksheet templates

## Run local tests
Requires Python 3.10 or later and the Python standard library only:

```
python -m unittest -v test_activation_model.py test_review_regressions.py
python arithmetic_checks.py
```

The archival Revision 9 baseline and internal editorial ledgers are **not in this reader package**. They remain available in the controlled historical review record. Do not interpret a successful simulation run as independent evidence of physical or operational system performance.

## Licensing
Intended copyright and attribution: © 2025–2026 Peter J. Hillier. CC BY 4.0 for author-owned published content (https://creativecommons.org/licenses/by/4.0/). The executable Python teaching code currently carries the same intended notice, pending the final software-licensing decision. Third-party materials, where separately identified, are not relicensed. Distribution is withheld pending provenance review and author release approval.
