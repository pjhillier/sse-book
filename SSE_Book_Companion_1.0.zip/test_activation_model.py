"""Run with: python -m unittest -v test_activation_model.py"""
from dataclasses import replace
import math
import unittest
from activation_model import ActivationModel, Authority, Request, Rejected, unsafe_restore_counterexample

class ModelTests(unittest.TestCase):
    def setUp(self):
        self.m = ActivationModel()
        self.r = Request("TX-41", "operator", "D1", "P8", 27, 0)
        self.a = Authority("operator", "D1", "NORMAL", True, True, 0, 100, approved_package="P8")
    def go(self, r=None, a=None, **kw):
        args = {"now":18.0,"delay_bound":8.0,"time_allowance":2.0}
        args.update(kw)
        return self.m.activate(r or self.r, a or self.a, **args)
    def test_valid_activation(self):
        self.assertEqual(self.go().committed_generation,28)
    def test_matching_repeat_has_one_effect(self):
        self.assertEqual(self.go(),self.go()); self.assertEqual(self.m.effect_count,1)
    def test_conflicting_identifier_rejected(self):
        self.go()
        with self.assertRaisesRegex(Rejected, "conflicting reuse"):
            self.go(replace(self.r,package="P9"), a=replace(self.a,approved_package="P9"))
        self.assertEqual(self.m.effect_count, 1)
    def test_configuration_conflict(self):
        with self.assertRaises(Rejected): self.go(replace(self.r,expected_generation=26))
    def test_missing_authentication(self):
        with self.assertRaises(Rejected): self.go(a=replace(self.a,authenticated=False))
    def test_missing_permission(self):
        with self.assertRaises(Rejected): self.go(a=replace(self.a,permitted=False))
    def test_subject_binding(self):
        with self.assertRaises(Rejected): self.go(a=replace(self.a,person="someone-else"))
    def test_target_binding(self):
        with self.assertRaises(Rejected): self.go(a=replace(self.a,target="D2"))
    def test_freshness_boundary_allowed(self):
        self.go(now=20); self.assertEqual(self.m.effect_count,1)
    def test_just_over_freshness_boundary_rejected(self):
        with self.assertRaises(Rejected): self.go(now=20.0001)
    def test_twelve_second_branch_rejected(self):
        with self.assertRaises(Rejected): self.go(delay_bound=12)
    def test_future_status_rejected(self):
        with self.assertRaises(Rejected): self.go(a=replace(self.a,observed_at=19))
    def test_nonfinite_time_rejected(self):
        with self.assertRaises(Rejected): self.go(now=math.nan)
    def test_expiry_includes_remaining_delay(self):
        with self.assertRaises(Rejected): self.go(a=replace(self.a,expires_at=27))
    def test_old_epoch_after_return_rejected(self):
        self.m.transition("RECOVERY");self.m.transition("NORMAL")
        with self.assertRaises(Rejected): self.go()
    def test_precommit_interruption_has_no_effect(self):
        with self.assertRaises(Rejected): self.go(fail_before_commit=True)
        self.assertEqual(self.m.effect_count,0);self.assertEqual(self.m.generation,27)
    def test_lost_reply_then_retry(self):
        with self.assertRaises(TimeoutError): self.go(lose_reply_after_commit=True)
        self.go();self.assertEqual(self.m.effect_count,1)
    def test_current_checkpoint_preserves_history(self):
        self.go();self.m.restore(self.m.snapshot());self.go();self.assertEqual(self.m.effect_count,1)
    def test_old_checkpoint_rejected(self):
        old=self.m.snapshot();self.go()
        with self.assertRaises(Rejected): self.m.restore(old)
    def test_modified_checkpoint_rejected(self):
        self.go();s=self.m.snapshot();s["history"]={}
        with self.assertRaises(Rejected): self.m.restore(s)
    def test_historical_and_current_outcomes_distinct(self):
        self.go();self.go(replace(self.r,transaction="TX-42",package="P9",expected_generation=28), a=replace(self.a,approved_package="P9"))
        q=self.m.query("TX-41",authorized_reader=True)
        self.assertEqual(q["historical_outcome"]["committed_generation"],28)
        self.assertEqual(q["current_generation"],29)
    def test_query_requires_own_authority(self):
        self.go()
        with self.assertRaises(Rejected): self.m.query("TX-41",authorized_reader=False)
    def test_valid_recovery_action(self):
        self.m.transition("RECOVERY")
        r=replace(self.r,mode="RECOVERY",epoch=1)
        a=replace(self.a,recovery_transaction="TX-41",recovery_generation=27,issued_at=0,approver_authenticated=True,mode="RECOVERY",approver="approver",approved_package="P8",active_local_roles=True,epoch=1)
        self.go(r,a);self.assertEqual(self.m.effect_count,1)
    def test_self_approval_rejected(self):
        self.m.transition("RECOVERY")
        r=replace(self.r,mode="RECOVERY",epoch=1)
        a=replace(self.a,recovery_transaction="TX-41",recovery_generation=27,issued_at=0,approver_authenticated=True,mode="RECOVERY",approver="operator",approved_package="P8",active_local_roles=True,epoch=1)
        with self.assertRaises(Rejected): self.go(r,a)
    def test_recovery_package_binding(self):
        self.m.transition("RECOVERY")
        r=replace(self.r,mode="RECOVERY",epoch=1)
        a=replace(self.a,recovery_transaction="TX-41",recovery_generation=27,issued_at=0,approver_authenticated=True,mode="RECOVERY",approver="approver",approved_package="P9",active_local_roles=True,epoch=1)
        with self.assertRaises(Rejected): self.go(r,a)
    def test_normal_package_binding(self):
        with self.assertRaises(Rejected): self.go(a=replace(self.a,approved_package="P9"))
    def test_action_binding(self):
        with self.assertRaises(Rejected): self.go(a=replace(self.a,action="read"))
    def test_receiver_target_binding(self):
        with self.assertRaises(Rejected): self.go(replace(self.r,target="D2"),replace(self.a,target="D2"))
    def test_authority_epoch_binding(self):
        with self.assertRaises(Rejected): self.go(a=replace(self.a,epoch=1))
    def test_negative_delay_rejected(self):
        with self.assertRaises(Rejected): self.go(delay_bound=-1)
    def test_empty_transaction_rejected(self):
        with self.assertRaises(Rejected): self.go(replace(self.r,transaction=""))
    def test_recovery_withdrawn_local_role_rejected(self):
        self.m.transition("RECOVERY")
        r=replace(self.r,mode="RECOVERY",epoch=1)
        a=replace(self.a,recovery_transaction="TX-41",recovery_generation=27,issued_at=0,approver_authenticated=True,mode="RECOVERY",epoch=1,approver="approver",active_local_roles=False)
        with self.assertRaises(Rejected): self.go(r,a)
    def test_recovery_requires_approver(self):
        self.m.transition("RECOVERY")
        r=replace(self.r,mode="RECOVERY",epoch=1)
        a=replace(self.a,recovery_transaction="TX-41",recovery_generation=27,issued_at=0,approver_authenticated=True,mode="RECOVERY",epoch=1,active_local_roles=True)
        with self.assertRaises(Rejected): self.go(r,a)
    def test_old_authority_after_return_rejected(self):
        self.m.transition("RECOVERY");self.m.transition("NORMAL")
        r=replace(self.r,epoch=2)
        with self.assertRaises(Rejected): self.go(r,self.a)
    def test_unsafe_restore_counterexample(self):
        self.assertEqual(len(unsafe_restore_counterexample()),4)

if __name__ == "__main__": unittest.main()
