"""Reproduce selected book arithmetic, not measured system performance.

All case inputs are invented or stipulated teaching values. Passing these checks
confirms only the stated calculations. It does not validate the models' assumptions,
physical premises, statistical sampling design, system implementation or authority.
Python 3.10+; standard library only.
"""
from __future__ import annotations
from math import isclose, isfinite
import json


def stopping_distance(v: float, delay: float, deceleration: float,
                      position_allowance: float, margin: float) -> float:
    if not all(isfinite(x) for x in (v, delay, deceleration, position_allowance, margin)):
        raise ValueError("finite inputs required")
    if min(v, delay, position_allowance, margin) < 0 or deceleration <= 0:
        raise ValueError("nonnegative motion inputs and positive deceleration required")
    return v * delay + v * v / (2 * deceleration) + position_allowance + margin



def stopping_distance_with_acceleration(
    starting_speed: float, delay: float, acceleration_bound: float,
    deceleration: float, position_allowance: float, margin: float,
) -> float:
    """Conservative illustrative bound for forward acceleration during latency.

    Assumes a stationary obstacle, straight-line motion, a nonnegative upper
    acceleration bound until braking, and at least the given deceleration
    thereafter. This is calculation, not a dynamics simulation or vehicle test.
    """
    values = (starting_speed, delay, acceleration_bound, deceleration,
              position_allowance, margin)
    if not all(isfinite(x) for x in values):
        raise ValueError("finite inputs required")
    if min(starting_speed, delay, acceleration_bound, position_allowance, margin) < 0 or deceleration <= 0:
        raise ValueError("nonnegative motion inputs and positive deceleration required")
    brake_onset_speed = starting_speed + acceleration_bound * delay
    return (starting_speed * delay + .5 * acceleration_bound * delay**2
            + brake_onset_speed**2 / (2 * deceleration)
            + position_allowance + margin)

def checks() -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    def check(name: str, value: float, expected: float, unit: str, scope: str) -> None:
        assert isclose(value, expected, rel_tol=1e-9, abs_tol=1e-9), (name, value, expected)
        rows.append({"example": name, "result": value, "unit": unit,
                     "arithmetic_check": "passed", "limit": scope})
    hypothetical = "Calculation over invented teaching inputs; not an observation."
    check("Chapter 7 withdrawal allocation", 10+20+5+8+2, 45, "seconds", hypothetical)
    check("Chapter 7 unallocated margin", 60-(10+20+5+8+2), 15, "seconds", hypothetical)
    check("Chapter 11 original freshness",18+8+2,28,"seconds",hypothetical)
    check("Chapter 11 changed freshness",18+12+2,32,"seconds",hypothetical)
    check("Chapter 11 maximum observed age with changed delay",30-12-2,16,"seconds",hypothetical)
    check("Chapter 11 changed withdrawal allocation",10+20+5+12+2,49,"seconds",hypothetical)
    check("Chapters 11 / Appendix C positive-operation allocation",.8+2+5+.7+.9,9.4,"seconds",hypothetical)
    check("Positive-operation numerical margin",10-9.4,.6,"seconds",hypothetical)
    check("One gateway snapshot unavailability",.02+.98*.01,.0298,"probability", "Invented snapshot inputs, not attack success or recovery time.")
    check("Two gateway snapshot unavailability",.02+.98*.01**2,.020098,"probability", "Assumes conditional local independence and only stated causes.")
    check("Two gateway snapshot availability",1-(.02+.98*.01**2),.979902,"probability", "Same limited snapshot model.")
    check("B preference at cost weight 0.4",.2+.55*.4,.42,"value", "Declared hypothetical preference function, not a security score.")
    check("C preference at cost weight 0.4",.6-.35*.4,.46,"value", "Feasibility gates assumed only for the illustration.")
    check("C changed-time preference",.25*.4+.45*.6,.37,"value", "Illustrates sensitivity; no measured cost or benefit.")
    check("B recovery task",2+4+2+3+2,13,"minutes",hypothetical)
    check("C recovery task",2+1+2+2+2,9,"minutes",hypothetical)
    check("Prepared authority temporal coverage",15+120+15,150,"minutes", "Not a credential-lifetime recommendation.")
    check("Maintenance latest fallback start",40-(12+6),22,"minutes", "Separate from SR-11; assumes sequential task bounds.")
    check("Cloud exit payload lower bound",60*8*1000/100/60,80,"minutes", "Decimal units; no overhead, so not a guaranteed completion time.")
    check("Cloud exit task lower bound",80+25+35+10,150,"minutes", "Specified sequential teaching arrangement.")
    check("Shared crew second completion",18+6+18,42,"minutes", "Independent infrastructure vignette, not administration recovery.")
    check("CB-09 analytical withdrawal bound",10+30,40,"seconds", "Requires source consistency, true observation age, timing and path premises.")
    check("CP-09 nominal stopping distance",stopping_distance(1.2,.35,.8,.15,.10),1.57,"metres", "Straight-line stationary-obstacle abstraction; physical premises unvalidated.")
    check("CP-09 increased-speed stopping distance",stopping_distance(1.8,.35,.8,.15,.10),2.905,"metres", "Same abstraction; exceeds assumed 2-metre usable distance.")
    check("CP-09 reduced-deceleration stopping distance",stopping_distance(1.2,.35,.4,.15,.10),2.47,"metres", "Same abstraction; no brake, sensor or vehicle test performed.")
    check("CB-09 reordered recovery allocation", 2+2+4+3+2, 13, "minutes", hypothetical)
    check("CB-09 stipulated task lower compatible bound",13.2-.3,12.9,"minutes", "Stipulated system evidence, not an actual participant measurement.")
    check("CB-09 stipulated task upper compatible bound",13.2+.3,13.5,"minutes", "Supports fifteen-minute criterion for the stipulated observation; not a thirteen-minute maximum.")
    check("CB-09 conservative observed headroom",15-(13.2+.3),1.5,"minutes", "Distinct from two-minute planned allocation margin.")
    check("CP-09 acceleration extension at zero acceleration",stopping_distance_with_acceleration(1.2,.35,0,.8,.15,.10),1.57,"metres", "Recovers the constant-speed latency assumption.")
    check("CP-09 acceleration extension at b=1",stopping_distance_with_acceleration(1.2,.35,1,.8,.15,.10),2.2328125,"metres", "New review sensitivity case; no measured acceleration, brake or vehicle.")
    check("CP-09 acceleration-extension excess",stopping_distance_with_acceleration(1.2,.35,1,.8,.15,.10)-2,.2328125,"metres", "Exceeds the same assumed two-metre usable detection distance.")
    return rows

if __name__ == "__main__":
    results = checks()
    print(json.dumps({"status": f"{len(results)} arithmetic checks passed", "checks": results}, indent=2))
