"""Executable teaching abstraction for Appendix C of The Security-Engineering Convergence.

NOT a security library, authentication service, persistence implementation, or verified
logistics system. All authentication and authorization inputs are stipulated test inputs.
Time is supplied by the caller; no clocks, networks, databases, devices or external services
are accessed. Atomic updates and a trustworthy anti-rollback anchor are model assumptions.
Copyright © 2026 Peter J. Hillier. Intended publication licence: Creative Commons Attribution 4.0 International (CC BY 4.0), subject to final third-party rights clearance. See README.md for scope and release status.
"""
from __future__ import annotations
from copy import deepcopy
from dataclasses import dataclass, asdict
from hashlib import sha256
import json
import math
from typing import Any

class Rejected(ValueError):
    """The model refused an activation or state import."""

@dataclass(frozen=True)
class Request:
    transaction: str
    person: str
    target: str
    package: str
    expected_generation: int
    epoch: int
    mode: str = "NORMAL"

@dataclass(frozen=True)
class Authority:
    """Trusted-oracle inputs in this abstraction, NOT verifiable credentials."""
    person: str
    target: str
    mode: str
    authenticated: bool
    permitted: bool
    observed_at: float
    expires_at: float
    approver: str | None = None
    approved_package: str | None = None
    active_local_roles: bool = False
    epoch: int = 0
    action: str = "activate"
    # Recovery grants bind one proposed operation. These remain trusted inputs;
    # this model neither issues nor cryptographically verifies an approval.
    recovery_transaction: str | None = None
    recovery_generation: int | None = None
    issued_at: float | None = None
    approver_authenticated: bool = False

@dataclass(frozen=True)
class Outcome:
    transaction: str
    package: str
    committed_generation: int

class ActivationModel:
    def __init__(self) -> None:
        self.target = "D1"  # one target only in this abstraction
        self.generation = 27
        self.epoch = 0
        self.mode = "NORMAL"
        self.package = "P7"
        self.history: dict[str, tuple[Request, Outcome]] = {}
        self.serial = 0
        self.effect_count = 0  # external observer used only by tests
        self._anchor = self._fingerprint(self.snapshot())

    @staticmethod
    def _fingerprint(state: dict[str, Any]) -> str:
        return sha256(json.dumps(state, sort_keys=True).encode("utf-8")).hexdigest()

    def snapshot(self) -> dict[str, Any]:
        return deepcopy({"generation": self.generation, "epoch": self.epoch,
                         "mode": self.mode, "package": self.package,
                         "serial": self.serial,
                         "history": {k: {"request": asdict(v[0]), "outcome": asdict(v[1])}
                                     for k, v in self.history.items()}})

    def _seal(self) -> None:
        # The joint durability of state and this protected anchor is ASSUMED here.
        # It is not supplied by this Python statement in a real deployment.
        self._anchor = self._fingerprint(self.snapshot())

    def restore(self, snapshot: dict[str, Any]) -> None:
        if self._fingerprint(snapshot) != self._anchor:
            raise Rejected("checkpoint does not match the retained current anchor")
        self.generation = snapshot["generation"]
        self.epoch = snapshot["epoch"]
        self.mode = snapshot["mode"]
        self.package = snapshot["package"]
        self.serial = snapshot["serial"]
        self.history = {k: (Request(**v["request"]), Outcome(**v["outcome"]))
                        for k, v in snapshot["history"].items()}

    def transition(self, mode: str) -> None:
        # A trusted test-driver/control-plane operation. Its real authorization
        # and transition mechanics are outside this deliberately small model.
        if mode not in {"NORMAL", "RECOVERY"}:
            raise Rejected("unknown mode")
        if mode == self.mode:
            return
        self.mode = mode
        self.epoch += 1
        self.serial += 1
        self._seal()

    def activate(self, request: Request, authority: Authority, *, now: float,
                 delay_bound: float, time_allowance: float,
                 fail_before_commit: bool = False,
                 lose_reply_after_commit: bool = False) -> Outcome:
        quantities = (now, delay_bound, time_allowance, authority.observed_at,
                      authority.expires_at)
        if not all(math.isfinite(x) for x in quantities) or min(delay_bound, time_allowance) < 0:
            raise Rejected("invalid time input")
        if not request.transaction or not request.person or not request.package:
            raise Rejected("empty request identity or content identifier")
        if request.target != self.target:
            raise Rejected("request is for a different receiving target")
        if request.person != authority.person or request.target != authority.target:
            raise Rejected("principal or target binding mismatch")
        if not authority.authenticated or not authority.permitted:
            raise Rejected("authentication or permission absent")
        if (request.mode != self.mode or authority.mode != self.mode
                or request.epoch != self.epoch or authority.epoch != self.epoch):
            raise Rejected("mode or epoch mismatch")
        if authority.action != "activate" or authority.approved_package != request.package:
            raise Rejected("action or approved package binding mismatch")
        predicted_latest_commit = now + delay_bound + time_allowance
        # Expiry is exclusive: authority must still be valid at the latest
        # conservatively predicted commit, not merely at the initial check.
        if predicted_latest_commit >= authority.expires_at or authority.observed_at > now:
            raise Rejected("expired or future authority")
        if self.mode == "NORMAL":
            age_bound = now - authority.observed_at + delay_bound + time_allowance
            if age_bound > 30:
                raise Rejected("normal authority too old at predicted commit")
        else:
            if (authority.issued_at is None or not math.isfinite(authority.issued_at)
                    or authority.issued_at > now
                    or authority.expires_at <= authority.issued_at
                    or authority.expires_at - authority.issued_at > 20 * 60):
                raise Rejected("invalid recovery grant issuance or lifetime")
            if (authority.recovery_transaction != request.transaction
                    or authority.recovery_generation != request.expected_generation):
                raise Rejected("single-operation recovery grant binding mismatch")
            if (not authority.approver_authenticated
                    or not authority.active_local_roles or not authority.approver
                    or authority.approver == request.person
                    or authority.approved_package != request.package):
                raise Rejected("independent recovery roles or package binding absent")
        if request.transaction in self.history:
            previous_request, outcome = self.history[request.transaction]
            if previous_request != request:
                raise Rejected("conflicting reuse of transaction identity")
            return outcome
        if request.expected_generation != self.generation:
            raise Rejected("configuration generation conflict")
        if fail_before_commit:
            raise Rejected("injected interruption before the abstract commit")
        # One indivisible transition IN THIS MODEL, not a database implementation.
        new_generation = self.generation + 1
        outcome = Outcome(request.transaction, request.package, new_generation)
        self.history[request.transaction] = (request, outcome)
        self.generation, self.package = new_generation, request.package
        self.serial += 1
        self.effect_count += 1
        self._seal()
        if lose_reply_after_commit:
            raise TimeoutError("reply lost; commit has already occurred in the model")
        return outcome

    def query(self, transaction: str, *, authorized_reader: bool) -> dict[str, Any]:
        if not authorized_reader:
            raise Rejected("outcome-reading authority absent")
        historical = self.history.get(transaction)
        return {"historical_outcome": asdict(historical[1]) if historical else None,
                "current_package": self.package, "current_generation": self.generation}


def unsafe_restore_counterexample() -> list[str]:
    """A deliberately incomplete abstract restore shows why history matters."""
    model = ActivationModel()
    before = model.snapshot()
    r = Request("TX-41", "operator", "D1", "P8", 27, 0)
    a = Authority("operator", "D1", "NORMAL", True, True, 0, 100, approved_package="P8")
    model.activate(r, a, now=10, delay_bound=1, time_allowance=0)
    # Deliberate violation of the protected-anchor rule. This is the faulty mutant.
    model.generation, model.package, model.epoch, model.history = 27, "P7", 0, {}
    model.serial = before["serial"]
    model.activate(r, a, now=11, delay_bound=1, time_allowance=0)
    assert model.effect_count == 2
    return ["1: TX-41 commits P8 from generation 27.",
            "2: Faulty restore erases execution history and restores generation 27.",
            "3: The same TX-41 appears new and commits again.",
            "External model observer counts two effects; the protected model rejects step 2."]
